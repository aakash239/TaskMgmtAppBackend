using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskManagement.Application.DTOs;
using TaskManagement.Application.Interfaces;
using System.Security.Claims;

namespace TaskManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]     // -> /api/auth
public class AuthController(IAuthService authService) : ControllerBase
{
    private readonly IAuthService _authService = authService;

    [HttpPost("login")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(AuthResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<AuthResponseDto>> Login(
        [FromBody] LoginRequestDto request,
        CancellationToken cancellationToken
    )
    {
        var response = await _authService.LoginAsync(request, cancellationToken);
        if(response is null)
        {
            return Problem(statusCode: StatusCodes.Status401Unauthorized, title: "Unathorized", detail: "Invalid Email and password");
        }
        return Ok(response);
    }

    [HttpGet("test")]
    public IActionResult Test()
    {
        return Ok("You are authenticated!!");
    }

    // POST /api/auth/signup
    [HttpPost("signup")]
    [AllowAnonymous]                                            // no token needed to sign up
    [ProducesResponseType(typeof(AuthResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> SignUp([FromBody] UserSignUpDto request, CancellationToken cancellationToken)
    {
        var result = await _authService.SignUpAsync(request, cancellationToken); 
        return StatusCode(StatusCodes.Status201Created, result);                 // 201 + body
    }

    // GET /api/auth/me: temporary endpoint 
    [HttpGet("me")]
    [Authorize]                                                 // requires a valid Bearer token
    public IActionResult Me()
    {
        return Ok(new
        {
            UserId = User.FindFirstValue("sub"),   // read claims back out of the validated token
            Email = User.FindFirstValue("email"),
            Name = User.FindFirstValue("name")
        });
    }
}